
public class RetrievalModelRankedBoolean extends RetrievalModel {

  public String defaultQrySopName () {
    return new String ("#or");
  }

@Override
public void printParams() {
	// TODO Auto-generated method stub
	
}

}